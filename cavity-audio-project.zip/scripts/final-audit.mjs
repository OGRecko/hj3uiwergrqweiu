import fs from "node:fs";
import path from "node:path";
const root=process.cwd(), files=[];
function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){if(["node_modules","dist",".git"].includes(e.name))continue;const p=path.join(d,e.name);e.isDirectory()?walk(p):files.push(p)}}
walk(root); const problems=[];
for(const f of files.filter(f=>/\.(ts|tsx|js|mjs|md|json|css)$/.test(f))){const s=fs.readFileSync(f,"utf8"); if(!/FINAL_FIX_REPORT\.md$|FINAL_VERIFICATION\.md$|final-audit\.mjs$/.test(f) && /1M CELLS MAX|1,000,000.*cell|MAX_GRID_CELLS\s*:\s*1_000_000|49,152,000/.test(s)) problems.push(`${path.relative(root,f)}: stale 1M grid reference`);}
const lim=fs.readFileSync(path.join(root,"src/lib/publicLimits.ts"),"utf8"); if(!/MAX_GRID_CELLS:\s*50_000_000/.test(lim)) problems.push("MAX_GRID_CELLS is not 50M");
const solver=fs.readFileSync(path.join(root,"server/solverWorker.ts"),"utf8"); if(!/frequency-dependent directivity/i.test(solver)) problems.push("directivity disclosure missing"); if(/getInterpolatedMagnitude\(source\.directivityData, 1000/.test(solver)) problems.push("hard-coded 1k directivity remains");
console.log(JSON.stringify({ok:!problems.length,filesScanned:files.length,problems},null,2)); process.exitCode=problems.length?1:0;
