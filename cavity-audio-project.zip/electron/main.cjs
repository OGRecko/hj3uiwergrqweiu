// Cavity Audio – Windows desktop shell.
// Starts the bundled production server (dist/server.cjs) on a free local port
// and shows the app in a native window.
const { app, BrowserWindow, shell, dialog } = require('electron');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');

let win = null;

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.listen(0, '127.0.0.1', () => { const { port } = s.address(); s.close(() => resolve(port)); });
    s.on('error', reject);
  });
}

function waitForServer(port, timeoutMs = 30000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      const req = http.get({ host: '127.0.0.1', port, path: '/', timeout: 1000 }, (res) => { res.resume(); resolve(); });
      req.on('error', () => (Date.now() - start > timeoutMs ? reject(new Error('Server did not start')) : setTimeout(tick, 250)));
      req.on('timeout', () => req.destroy());
    };
    tick();
  });
}

async function startServer() {
  const port = await freePort();
  const root = app.isPackaged ? path.join(process.resourcesPath, 'app') : path.join(__dirname, '..');
  process.chdir(root); // server serves ./dist relative to cwd
  process.env.PORT = String(port);
  // Local desktop mode: loopback only, local in-process job store (no cloud credentials needed).
  process.env.NODE_ENV = 'development';
  process.env.CAVITY_DESKTOP = '1';
  require(path.join(root, 'dist', 'server.cjs'));
  await waitForServer(port);
  return port;
}

async function createWindow() {
  const port = await startServer();
  win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1024, minHeight: 700,
    backgroundColor: '#0b0b0c', title: 'Cavity Audio', autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  await win.loadURL(`http://127.0.0.1:${port}/app`);
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => createWindow().catch((e) => {
    dialog.showErrorBox('Cavity Audio failed to start', String(e && e.message || e));
    app.quit();
  }));
  app.on('window-all-closed', () => app.quit());
}
