// speakerDSP.ts
// Derives a real Web Audio filter chain from a speaker's published specs.
// This is a physically-motivated approximation, not a lab-measured impulse
// response — but every stage below is doing genuine signal processing driven
// by the actual spec numbers (freq range, driver size, power, driver count).

import { getSpeakerResponseModel, interpolateLogFrequency, type ResponsePoint } from './speakerResponse';

export type VerificationStatus = 'MANUFACTURER_VERIFIED' | 'MEASUREMENT_VERIFIED' | 'ESTIMATED' | 'UNAVAILABLE' | 'LEGACY';
export type SourceType = 'MANUFACTURER' | 'MEASUREMENT' | 'REPUTABLE_DATABASE' | 'RETAILER' | 'ESTIMATE' | 'UNKNOWN' | 'NONE';

export interface SpecField<T> {
  value: T | null;
  unit: string;
  status: VerificationStatus;
  source: string | null;
  sourceType: SourceType;
}

export type OverallStatus = 'FULLY_VERIFIED' | 'PARTIALLY_VERIFIED' | 'MEASUREMENT_VERIFIED' | 'LEGACY' | 'UNAVAILABLE';

export interface SpeakerSpec {
  id: string;
  brand: string;
  model: string;
  category: string;
  year: number | null;
  overallStatus: OverallStatus;
  driverCount: number;
  active: boolean;
  panel: boolean;
  notes: string | null;

  frequencyResponse: {
    low_hz: number | null;
    high_hz: number | null;
    status: VerificationStatus;
    source: string | null;
    sourceType: SourceType;
    points?: ResponsePoint[];
  };
  sensitivity: SpecField<number>;
  power: SpecField<number>;
  impedance: SpecField<number>;
  resonantFreq: SpecField<number>;
  voiceCoil: SpecField<number>;
  woofer: SpecField<number>;
}

export interface SpeakerAudioChain {
  input: GainNode;
  output: GainNode;
  nodes: AudioNode[];
  dispose: () => void;
}

export interface SpeakerChainOptions {
  loudnessMatched?: boolean;
  distanceM?: number;
  angleRad?: number;
}

// Some entries in the merged speaker library come from the legacy
// speakers.ts list (source: "legacy") and only have brand/model/year/
// category/sens_db — they predate the full spec schema below and we do
// not fabricate driver/frequency/power numbers for them. This fills in
// conservative, clearly-labeled flat-response defaults so buildSpeakerChain
// doesn't crash on missing fields; it intentionally does NOT attempt to
// approximate real per-speaker character for these entries.
export function normalizeSpeakerSpec(raw: any): SpeakerSpec {
  if (raw.overallStatus !== "LEGACY") return raw as SpeakerSpec;

  const sensValue = raw.sensitivity?.value || raw.sens_db || null;

  return {
    id: raw.id || 'unknown',
    brand: raw.brand || 'Unknown',
    model: raw.model || 'Unknown',
    category: raw.category || 'unknown',
    year: raw.year || null,
    overallStatus: 'LEGACY',
    driverCount: 2,
    active: false,
    panel: false,
    notes: (raw.notes || '') + ' [Legacy entry: speaker-specific driver/frequency/power specs unavailable; DSP uses explicit generic fallback parameters only]',
    frequencyResponse: { low_hz: null, high_hz: null, status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    sensitivity: { value: sensValue, unit: 'dB', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    power: { value: null, unit: 'W', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    impedance: { value: null, unit: 'ohm', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    resonantFreq: { value: null, unit: 'Hz', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    voiceCoil: { value: null, unit: 'in', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    woofer: { value: null, unit: 'in', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' }
  };
}

/**
 * Build a chain of real Web Audio nodes whose parameters are derived
 * mathematically from the speaker's spec sheet:
 *
 *  1. Low-shelf filter   — rolloff below freqLow_hz. Smaller woofers and
 *     higher freqLow_hz specs roll off earlier and more steeply (physical
 *     reality: small cones can't move enough air for deep bass).
 *  2. High-shelf filter  — rolloff above freqHigh_hz, softened/extended
 *     for tweeter types implied by high freqHigh_hz values (ribbon/beryllium
 *     designs in real speakers report >30kHz; this reflects that in the curve).
 *  3. Presence/proximity peak — driver count and category shape a broad
 *     midrange peaking filter (horn-loaded PA/vintage horn speakers get a
 *     forward upper-mid bump consistent with their real high-sensitivity
 *     horn geometry; multi-way studio monitors get a flatter response).
 *  4. WaveShaper (soft saturation) — power handling drives how much headroom
 *     the chain has before soft-clipping character appears, approximating
 *     how lower-power/vintage drivers compress and add harmonic coloration
 *     sooner than a high-power modern active monitor.
 *  5. Compressor — active/DSP-driven modern PA and studio monitors get a
 *     tighter, more controlled dynamic response (real behavior of onboard
 *     DSP limiters); passive vintage speakers get looser dynamics.
 */
export function buildSpeakerChain(
  ctx: AudioContext,
  rawSpec: SpeakerSpec,
  options?: SpeakerChainOptions
): SpeakerAudioChain {
  const spec = normalizeSpeakerSpec(rawSpec);
  const responseModel = getSpeakerResponseModel(spec);
  const input = ctx.createGain();
  const output = ctx.createGain();
  const nodes: AudioNode[] = [];

  // Gain staging: physical sensitivity, distance, and directivity angle
  const gainNode = ctx.createGain();
  let linearGain = 1.0;
  if (!options?.loudnessMatched) {
    const sens = spec.sensitivity?.value || 89;
    linearGain = Math.pow(10, (sens - 89) / 20);
  }
  if (options?.distanceM != null) {
    const d = Math.max(0.5, options.distanceM);
    linearGain /= d;
  }
  if (options?.angleRad != null) {
    const deg = Math.abs((options.angleRad * 180) / Math.PI);
    const dirFactor = Math.max(0.1, Math.cos((deg * Math.PI) / 360));
    linearGain *= dirFactor;
  }
  gainNode.gain.value = linearGain;
  nodes.push(gainNode);

  // ---- Narrow-band drivers (guitar cab speakers, car audio) take a
  // different signal path: they're not trying to be flat/full-range, so
  // model them as a bandpass centered near resonant frequency instead of
  // shelving filters meant for full-range speakers. ----
  if (spec.category === "guitar-cab" || spec.category === "car-audio") {
    return buildNarrowBandChain(ctx, spec, input, output, nodes, options);
  }

  // ---- 1. Low-end shelf, derived from response curve at 50 Hz ----
  const bassGain50 = clamp(interpolateLogFrequency(responseModel.points, 50), -24, 6);
  const lowShelf = ctx.createBiquadFilter();
  lowShelf.type = "lowshelf";
  lowShelf.frequency.value = clamp(responseModel.low_hz, 20, 300);
  lowShelf.gain.value = bassGain50;
  nodes.push(lowShelf);

  // ---- 2. Parametric peaking filter bank across octave centers ----
  const octaveBands = [125, 250, 500, 1000, 2000, 4000, 8000];
  const peakFilters: BiquadFilterNode[] = [];
  for (const centerHz of octaveBands) {
    const bandGain = clamp(interpolateLogFrequency(responseModel.points, centerHz), -18, 12);
    if (Math.abs(bandGain) > 0.1) {
      const peak = ctx.createBiquadFilter();
      peak.type = "peaking";
      peak.frequency.value = centerHz;
      peak.Q.value = 1.4;
      peak.gain.value = bandGain;
      peakFilters.push(peak);
      nodes.push(peak);
    }
  }

  // ---- 3. High-end shelf, derived from response curve at 15 kHz ----
  const trebleGain15k = clamp(interpolateLogFrequency(responseModel.points, 15000), -24, 6);
  const highShelf = ctx.createBiquadFilter();
  highShelf.type = "highshelf";
  highShelf.frequency.value = clamp(responseModel.high_hz, 4000, 20000);
  highShelf.gain.value = trebleGain15k;
  nodes.push(highShelf);

  // ---- 4. Soft saturation, derived from power handling ----
  const shaper = ctx.createWaveShaper();
  shaper.curve = makeSaturationCurve((spec.power?.value || 50), spec.year);
  shaper.oversample = "4x";
  nodes.push(shaper);

  // ---- 5. Dynamics, derived from active/DSP status ----
  const compressor = ctx.createDynamicsCompressor();
  if (spec.active) {
    compressor.threshold.value = -12;
    compressor.ratio.value = 4;
    compressor.attack.value = 0.003;
    compressor.release.value = 0.15;
  } else {
    compressor.threshold.value = -6;
    compressor.ratio.value = 2;
    compressor.attack.value = 0.01;
    compressor.release.value = 0.3;
  }
  nodes.push(compressor);

  // Wire the chain: input -> lowShelf -> [peakFilters] -> highShelf -> shaper -> compressor -> gainNode -> output
  let prev: AudioNode = input;
  prev.connect(lowShelf);
  prev = lowShelf;

  for (const pf of peakFilters) {
    prev.connect(pf);
    prev = pf;
  }

  prev.connect(highShelf);
  highShelf.connect(shaper);
  shaper.connect(compressor);
  compressor.connect(gainNode);
  gainNode.connect(output);

  return {
    input,
    output,
    nodes: [gainNode, lowShelf, ...peakFilters, highShelf, shaper, compressor],
    dispose: () => {
      nodes.forEach((n) => {
        try {
          n.disconnect();
        } catch {
          /* already disconnected */
        }
      });
    },
  };
}

/**
 * Narrow-band chain for guitar cab drivers and car audio subs/mids.
 * These are NOT trying to reproduce a flat frequency range — a guitar
 * speaker is intentionally colored/resonant, and a car sub is optimized
 * for a narrow low-frequency band with high excursion. Modeling them as
 * a bandpass around their resonant frequency (Fs) is closer to how they
 * actually behave than forcing a hi-fi lowshelf/highshelf onto them.
 */
function buildNarrowBandChain(
  ctx: AudioContext,
  spec: SpeakerSpec,
  input: GainNode,
  output: GainNode,
  nodes: AudioNode[],
  options?: SpeakerChainOptions
): SpeakerAudioChain {
  const fs = spec.resonantFreq?.value ?? (spec.category === "car-audio" ? 35 : 90);

  // Bandpass centered on resonant frequency — narrower Q for car subs
  // (tuned box, narrow-band output), wider for guitar drivers (broader
  // midrange character with natural rolloff on both ends).
  const bandpass = ctx.createBiquadFilter();
  bandpass.type = "bandpass";
  bandpass.frequency.value = fs;
  bandpass.Q.value = spec.category === "car-audio" ? 1.4 : 0.7;
  nodes.push(bandpass);

  // Guitar cab drivers are famously midrange-forward and "honky" —
  // real Celestion/Jensen drivers have a characteristic upper-mid hump.
  const midHump = ctx.createBiquadFilter();
  midHump.type = "peaking";
  midHump.frequency.value = spec.category === "guitar-cab" ? 2000 : 60;
  midHump.Q.value = 1;
  midHump.gain.value = spec.category === "guitar-cab" ? 6 : 2;
  nodes.push(midHump);

  // Sensitivity affects perceived loudness/output gain — higher
  // sensitivity (dB @ 1W/1m) drivers are louder for the same input.
  const sensGain = ctx.createGain();
  if (options?.loudnessMatched) {
    sensGain.gain.value = 1.0;
  } else {
    const sens = spec.sensitivity?.value ?? 92;
    sensGain.gain.value = clamp((sens - 85) / 15, 0.3, 2.5);
  }
  nodes.push(sensGain);

  // Guitar speakers break up and distort readily by design; car subs
  // stay cleaner but compress hard near excursion limits.
  const shaper = ctx.createWaveShaper();
  shaper.curve = makeSaturationCurve(
    spec.category === "guitar-cab" ? (spec.power?.value || 50) * 0.3 : (spec.power?.value || 50),
    spec.category === "guitar-cab" ? 1955 : spec.year // force an "eager to saturate" character for guitar drivers
  );
  shaper.oversample = "4x";
  nodes.push(shaper);

  input.connect(bandpass);
  bandpass.connect(midHump);
  midHump.connect(sensGain);
  sensGain.connect(shaper);
  shaper.connect(output);

  return {
    input,
    output,
    nodes,
    dispose: () => {
      nodes.forEach((n) => {
        try {
          n.disconnect();
        } catch {
          /* already disconnected */
        }
      });
    },
  };
}

/** Builds a WaveShaper curve whose softness scales with rated power and era.
 *  Lower power handling + older era => saturates/compresses sooner (smaller
 *  drivers and older voice coils reach thermal/mechanical limits faster).
 *  This is a simplified but real nonlinear transfer function, not decorative.
 */
function makeSaturationCurve(power_w: number, year: number | null): Float32Array<ArrayBuffer> {
  const samples = 1024;
  const curve = new Float32Array(new ArrayBuffer(samples * Float32Array.BYTES_PER_ELEMENT));
  // Normalize: low power (e.g. 20W vintage) => low knee; high power
  // (e.g. 2000W modern PSU) => knee pushed far out, nearly linear.
  const powerFactor = clamp(power_w / 500, 0.15, 3);
  // year can be null (e.g. legacy speaker entries with no known year — see
  // normalizeSpeakerSpec). Previously this ran `null - 1950` directly,
  // which coerces to -1950 and clamps to the 0.2 floor — happening to land
  // on a plausible-looking "old/soft knee" value by accident, but as an
  // unintended side effect of numeric coercion rather than a real default.
  // Treat unknown year explicitly as a mid-era assumption instead.
  const eraFactor = year != null ? clamp((year - 1950) / 75, 0.2, 1) : 0.6; // older = softer knee; unknown year -> neutral middle assumption
  const knee = clamp(powerFactor * eraFactor, 0.2, 2.5);

  for (let i = 0; i < samples; i++) {
    const x = (i * 2) / samples - 1; // -1 to 1
    curve[i] = Math.tanh(x * (1 + 1 / knee)) / Math.tanh(1 + 1 / knee);
  }
  return curve;
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}
