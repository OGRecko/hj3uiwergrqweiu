import { openDB, DBSchema, IDBPDatabase } from 'idb';

export interface ProjectRecord {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  isArchived: boolean;
  data: any;
}

interface AppSettings {
  id: string; // 'activeProjectId'
  value: string | null;
}

interface CavityDB extends DBSchema {
  projects: {
    key: string;
    value: ProjectRecord;
    indexes: { 'by-updated': number };
  };
  settings: {
    key: string;
    value: AppSettings;
  };
}

let dbPromise: Promise<IDBPDatabase<CavityDB>> | null = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB<CavityDB>('cavity-audio-projects', 1, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('projects')) {
          const store = db.createObjectStore('projects', { keyPath: 'id' });
          store.createIndex('by-updated', 'updatedAt');
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
}

export const LocalStore = {
  async getProjects() {
    const db = await getDB();
    const all = await db.getAllFromIndex('projects', 'by-updated');
    return all.sort((a, b) => b.updatedAt - a.updatedAt);
  },
  
  async getProject(id: string) {
    const db = await getDB();
    return await db.get('projects', id);
  },
  
  async saveProject(project: ProjectRecord) {
    const db = await getDB();
    await db.put('projects', project);
  },
  
  async deleteProject(id: string) {
    const db = await getDB();
    await db.delete('projects', id);
  },
  
  async getActiveProjectId(): Promise<string | null> {
    const db = await getDB();
    const setting = await db.get('settings', 'activeProjectId');
    return setting?.value ?? null;
  },
  
  async setActiveProjectId(id: string | null) {
    const db = await getDB();
    await db.put('settings', { id: 'activeProjectId', value: id });
  }
};
