# Cavity Audio — Final Fix Pass

This pass is based on `cavity_audio_final_all_v5.zip` and targets the remaining release-hardening items that are fixable in the source tree without access to the user's real Firebase/GCP production project.

## Fixed

- Tightened speaker database regression tests to the actual current database size: 774 records, 80 LEGACY, 694 non-legacy.
- Cleared undo/redo history after project import and autosave recovery so history from another project cannot be applied to the newly loaded project.
- Project import errors now surface the validation reason instead of only `Failed to load project.`
- Strengthened project-file validation:
  - rejects future schema versions instead of silently downgrading them;
  - migrates schema-less legacy project files to the current schema;
  - validates wall-material arrays and wall openings;
  - validates scatter ranges;
  - validates receiver-grid bounds, height and spacing;
  - validates project/room labels and UX/accuracy modes;
  - validates simulation references and names;
  - validates primary receiver references;
  - sanitizes imported project data to the supported project shape.
- Fixed a TypeScript discriminated-union error in the directivity validation path (`publicLimits.ts`).
- Added focused project-validation regression tests.

## Verification completed in this environment

- `node scripts/final-audit.mjs` — PASS.
- `node scripts/release-audit.mjs` — PASS; 774 speaker records, zero duplicate IDs, zero duplicate brand/model pairs, zero audit warnings.
- Speaker database counts independently checked — PASS: 774 total / 80 LEGACY / 694 non-legacy.
- Focused TypeScript check for the modified validation modules — PASS.
- JavaScript syntax checks for release scripts — PASS.
- JSON parsing for package metadata and speaker database — PASS.

## Verification intentionally not claimed

The environment does not have a complete dependency installation and does not have the user's real Firebase/GCP production credentials. Therefore this artifact does **not** claim that these production-only checks were executed here:

- `npm ci` on Node 22.23.2
- full `npm run typecheck`
- full `npm test`
- Firebase emulator/rules execution
- production Vite/server build with installed dependencies
- `npm audit --audit-level=high`
- real production smoke test
- real Cloud Storage lifecycle inspection
- real abuse/load test against the deployed service
- real 50M-cell hardware/load execution

The source tree retains the existing production smoke, lifecycle and abuse scripts for the deployment environment. The release must be considered unverified until those environment-dependent checks are run against the actual deployment.

## Release requirement

Use Node `22.23.2` exactly, run `npm ci`, then execute the project's release verification sequence against the real Firebase/GCP deployment before launch. The 50M-cell setting remains a hard technical ceiling, not a guarantee that every 50M-cell job is practical on every Cloud Run/CPU configuration.
